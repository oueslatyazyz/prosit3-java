package services;

import entities.Departement;
import interfaces.IDepartement;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public class DepartementHashSet implements IDepartement<Departement> {
    private final HashSet<Departement> departements = new HashSet<>();

    @Override
    public void ajouterDepartement(Departement departement) {
        departements.add(departement);
    }

    @Override
    public boolean rechercherDepartement(String nomDepartement) {
        return departements.stream()
                .anyMatch(departement -> Objects.equals(
                        departement.getNomDepartement(), nomDepartement));
    }

    @Override
    public boolean rechercherDepartement(Departement departement) {
        return departements.contains(departement);
    }

    @Override
    public void supprimerDepartement(Departement departement) {
        departements.remove(departement);
    }

    @Override
    public void afficherDepartements() {
        departements.forEach(System.out::println);
    }

    @Override
    public void trierDepartementsParId() {
        List<Departement> departementsTries = new ArrayList<>(departements);
        departementsTries.sort(Comparator.comparingInt(Departement::getId));
        departementsTries.forEach(System.out::println);
    }

    @Override
    public void trierDepartementsParNomEtNombreEmployes() {
        List<Departement> departementsTries = new ArrayList<>(departements);
        departementsTries.sort(
                Comparator.comparing(Departement::getNomDepartement)
                        .thenComparingInt(Departement::getNombreEmployes));
        departementsTries.forEach(System.out::println);
    }
}
