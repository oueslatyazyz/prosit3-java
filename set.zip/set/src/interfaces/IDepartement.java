package interfaces;

public interface IDepartement<T> {
    void ajouterDepartement(T departement);

    boolean rechercherDepartement(String nomDepartement);

    boolean rechercherDepartement(T departement);

    void supprimerDepartement(T departement);

    void afficherDepartements();

    void trierDepartementsParId();

    void trierDepartementsParNomEtNombreEmployes();
}
