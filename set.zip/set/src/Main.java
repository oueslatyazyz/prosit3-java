import entities.Departement;
import services.DepartementHashSet;

public class Main {
    public static void main(String[] args) {
        DepartementHashSet gestionDepartements = new DepartementHashSet();

        Departement informatique = new Departement(1, "Informatique", 12);
        Departement mathematiques = new Departement(2, "Mathematiques", 8);
        Departement physique = new Departement(3, "Physique", 10);

        gestionDepartements.ajouterDepartement(informatique);
        gestionDepartements.ajouterDepartement(mathematiques);
        gestionDepartements.ajouterDepartement(physique);

        System.out.println("Departements :");
        gestionDepartements.afficherDepartements();

        System.out.println("\nInformatique existe : "
                + gestionDepartements.rechercherDepartement("Informatique"));
        System.out.println("Le departement 2 existe : "
                + gestionDepartements.rechercherDepartement(mathematiques));

        System.out.println("\nTri par identifiant :");
        gestionDepartements.trierDepartementsParId();

        System.out.println("\nTri par nom puis par nombre d'employes :");
        gestionDepartements.trierDepartementsParNomEtNombreEmployes();

        gestionDepartements.supprimerDepartement(physique);
        System.out.println("\nApres suppression de Physique :");
        gestionDepartements.afficherDepartements();
    }
}
