package tn.esprit.gestionzoo.entities;

public class Zoo {
    private int nbrCages;                       // capacité modifiable via setter, avec validation
    private Animal[] animals;
    private int animalCount = 0;                // compteur d'animaux présents
    private String name = "Zoo sans nom";     // valeur par défaut valide
    private String city = "Inconnue";

    public Zoo() {
        this("Zoo sans nom", "Inconnue", 25);
    }

    public Zoo(String name, String city) {
        this(name, city, 25);
    }

    public Zoo(String name, String city, int nbrCages) {
        this.animals = new Animal[0];
        setName(name);
        setCity(city);
        setNbrCages(nbrCages);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            System.out.println("Erreur : le nom du zoo ne peut pas être vide.");
            return;
        }
        this.name = name.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        if (city == null || city.trim().isEmpty()) {
            System.out.println("Erreur : la ville du zoo ne peut pas être vide.");
            return;
        }
        this.city = city.trim();
    }

    public int getNbrCages() {
        return nbrCages;
    }

    public void setNbrCages(int nbrCages) {
        if (nbrCages <= 0) {
            System.out.println("Erreur : le nombre de cages doit être strictement positif.");
            return;
        }
        if (animalCount > nbrCages) {
            System.out.println("Erreur : impossible de réduire le zoo à " + nbrCages + " cages, il contient déjà " + animalCount + " animaux.");
            return;
        }

        Animal[] newAnimals = new Animal[nbrCages];
        for (int i = 0; i < animalCount; i++) {
            newAnimals[i] = animals[i];
        }
        this.animals = newAnimals;
        this.nbrCages = nbrCages;
    }

    public int getAnimalCount() {
        return animalCount;
    }

    public void displayZoo() {
        System.out.println("Zoo : " + name + ", Ville : " + city + ", Cages : " + nbrCages);
    }

    @Override
    public String toString() {
        return "Zoo [Nom=" + name + ", Ville=" + city + ", Cages=" + nbrCages
                + ", Animaux=" + animalCount + "]";
    }

    public boolean isZooFull() {
        return animalCount >= nbrCages;
    }

    public boolean addAnimal(Animal animal) {
        if (animal == null || isZooFull()) {
            return false;
        }
        if (searchAnimal(animal) != -1) {
            return false;
        }
        animals[animalCount] = animal;
        animalCount++;
        return true;
    }

    public void displayAnimals() {
        if (animalCount == 0) {
            System.out.println("Aucun animal dans le zoo " + name);
            return;
        }
        System.out.println("Animaux du zoo " + name + " (" + animalCount + "/" + nbrCages + ") :");
        for (int i = 0; i < animalCount; i++) {
            System.out.println("  [" + i + "] " + animals[i]);
        }
    }

    public int searchAnimal(Animal animal) {
        if (animal == null || animal.getName() == null) {
            return -1;
        }
        for (int i = 0; i < animalCount; i++) {
            if (animals[i] != null && animals[i].getName().equalsIgnoreCase(animal.getName())) {
                return i;
            }
        }
        return -1;
    }

    public boolean removeAnimal(Animal animal) {
        int index = searchAnimal(animal);
        if (index == -1) {
            return false;
        }
        for (int i = index; i < animalCount - 1; i++) {
            animals[i] = animals[i + 1];
        }
        animals[animalCount - 1] = null;
        animalCount--;
        return true;
    }

    public static Zoo comparerZoo(Zoo z1, Zoo z2) {
        if (z1 == null && z2 == null) {
            return null;
        }
        if (z1 == null) {
            return z2;
        }
        if (z2 == null) {
            return z1;
        }
        return (z1.getAnimalCount() >= z2.getAnimalCount()) ? z1 : z2;
    }
}