package tn.esprit.gestionzoo.entities;

public class Terrestrial extends Animal {
    protected int nbrLegs;

    public Terrestrial() {
        super();
        this.nbrLegs = 0;
    }

    public Terrestrial(String family, String name, int age, boolean isMammal, int nbrLegs) {
        super(family, name, age, isMammal);
        setNbrLegs(nbrLegs);
    }

    public int getNbrLegs() {
        return nbrLegs;
    }

    public void setNbrLegs(int nbrLegs) {
        if (nbrLegs < 0) {
            System.out.println("Erreur : le nombre de pattes ne peut pas être négatif.");
            return;
        }
        this.nbrLegs = nbrLegs;
    }

    @Override
    public String toString() {
        return "Terrestrial [Famille=" + getFamily() + ", Nom=" + getName() + ", Âge=" + getAge()
                + ", Mammifère=" + isMammal() + ", Nombre de pattes=" + nbrLegs + "]";
    }
}
