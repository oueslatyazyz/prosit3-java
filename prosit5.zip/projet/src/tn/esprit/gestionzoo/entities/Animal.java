package tn.esprit.gestionzoo.entities;

public class Animal {
    protected String family;
    protected String name;
    protected int age;
    protected boolean isMammal;

    public Animal() {
        this.family = "Inconnue";
        this.name = "Inconnu";
        this.age = 0;
        this.isMammal = false;
    }

    // Constructeur paramétré : passe par les setters pour appliquer les validations
    public Animal(String family, String name, int age, boolean isMammal) {
        setFamily(family);
        setName(name);
        setAge(age);
        this.isMammal = isMammal;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        if (family == null || family.trim().isEmpty()) {
            System.out.println("Erreur : la famille de l'animal ne peut pas être vide.");
            return;
        }
        this.family = family.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            System.out.println("Erreur : le nom de l'animal ne peut pas être vide.");
            return;
        }
        this.name = name.trim();
    }

    public int getAge() {
        return age;
    }

    // Un animal ne peut pas avoir un âge négatif
    public void setAge(int age) {
        if (age < 0) {
            System.out.println("Erreur : l'âge ne peut pas être négatif (valeur ignorée : " + age + ").");
            return;
        }
        this.age = age;
    }

    public boolean isMammal() {
        return isMammal;
    }

    public void setMammal(boolean mammal) {
        isMammal = mammal;
    }

    @Override
    public String toString() {
        return "Animal [Famille=" + family + ", Nom=" + name + ", Âge=" + age + ", Mammifère=" + isMammal + "]";
    }
}