package tn.esprit.gestionzoo.entities;

public class Aquatic extends Animal {
    protected String habitat;

    public Aquatic() {
        super();
        this.habitat = "Inconnu";
    }

    public Aquatic(String family, String name, int age, boolean isMammal, String habitat) {
        super(family, name, age, isMammal);
        setHabitat(habitat);
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        if (habitat == null || habitat.trim().isEmpty()) {
            System.out.println("Erreur : l'habitat ne peut pas être vide.");
            return;
        }
        this.habitat = habitat.trim();
    }

    public void swim() {
        System.out.println("This aquatic animal is swimming.");
    }

    @Override
    public String toString() {
        return "Aquatic [Famille=" + getFamily() + ", Nom=" + getName() + ", Âge=" + getAge()
                + ", Mammifère=" + isMammal() + ", Habitat=" + habitat + "]";
    }
}
