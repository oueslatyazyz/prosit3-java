package tn.esprit.gestionzoo.entities;

public class Dolphin extends Aquatic {
    protected float swimmingSpeed;

    public Dolphin() {
        super();
        this.swimmingSpeed = 0.0f;
    }

    public Dolphin(String family, String name, int age, boolean isMammal, String habitat, float swimmingSpeed) {
        super(family, name, age, isMammal, habitat);
        setSwimmingSpeed(swimmingSpeed);
    }

    public float getSwimmingSpeed() {
        return swimmingSpeed;
    }

    public void setSwimmingSpeed(float swimmingSpeed) {
        if (swimmingSpeed < 0) {
            System.out.println("Erreur : la vitesse de nage ne peut pas être négative.");
            return;
        }
        this.swimmingSpeed = swimmingSpeed;
    }

    @Override
    public void swim() {
        System.out.println("This dolphin is swimming.");
    }

    @Override
    public String toString() {
        return "Dolphin [Famille=" + getFamily() + ", Nom=" + getName() + ", Âge=" + getAge()
                + ", Mammifère=" + isMammal() + ", Habitat=" + habitat + ", Vitesse de nage=" + swimmingSpeed + "]";
    }
}
