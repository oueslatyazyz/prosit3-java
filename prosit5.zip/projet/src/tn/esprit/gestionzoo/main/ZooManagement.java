package tn.esprit.gestionzoo.main;

import tn.esprit.gestionzoo.entities.Animal;
import tn.esprit.gestionzoo.entities.Aquatic;
import tn.esprit.gestionzoo.entities.Dolphin;
import tn.esprit.gestionzoo.entities.Penguin;
import tn.esprit.gestionzoo.entities.Terrestrial;
import tn.esprit.gestionzoo.entities.Zoo;

import java.util.Scanner;

public class ZooManagement {
    public static void main(String[] args) {
        // ===== Saisie avec validation =====,k
        Scanner sc = new Scanner(System.in);

        String zooName = "Mon Zoo";
        if (sc.hasNextLine()) {
            do {
                System.out.print("Entrez le nom du zoo : ");
                zooName = sc.nextLine().trim();
            } while (zooName.isEmpty());
        } else {
            System.out.println("Aucune saisie détectée, utilisation du nom par défaut : " + zooName);
        }

        int nbrCages = 25;
        if (sc.hasNextInt()) {
            do {
                System.out.print("Entrez le nombre de cages (entier positif) : ");
                while (!sc.hasNextInt()) {
                    System.out.print("Entier requis : ");
                    sc.next();
                }
                nbrCages = sc.nextInt();
            } while (nbrCages <= 0);
        } else {
            System.out.println("Aucune valeur saisie, utilisation de 25 cages par défaut.");
        }

        System.out.println(zooName + " comporte " + nbrCages + " cages.");

        // ===== Prosit 3 =====
        Zoo myZoo = new Zoo(zooName, "Tunis", nbrCages);
        myZoo.displayZoo();

        Animal lion = new Animal("Félidé", "Lion", 5, true);
        Animal tigre = new Animal("Félidé", "Tigre", 4, true);
        Animal aigle = new Animal("Accipitridé", "Aigle", 3, false);

        System.out.println("Ajout lion  : " + myZoo.addAnimal(lion));
        System.out.println("Ajout tigre : " + myZoo.addAnimal(tigre));
        System.out.println("Ajout aigle : " + myZoo.addAnimal(aigle));

        myZoo.displayAnimals();
        System.out.println("Recherche lion : " + myZoo.searchAnimal(lion));

        Animal lionCopie = new Animal("Félidé", "Lion", 5, true);
        System.out.println("Recherche copie du lion : " + myZoo.searchAnimal(lionCopie));
        System.out.println("Ajout de la copie du lion (doublon) : " + myZoo.addAnimal(lionCopie));

        for (int i = 1; i <= 25; i++) {
            boolean ok = myZoo.addAnimal(new Animal("Test", "Animal" + i, 1, true));
            if (!ok) {
                System.out.println("Ajout refusé pour Animal" + i + " : zoo plein = " + myZoo.isZooFull());
                break;
            }
        }
        System.out.println(myZoo);

        System.out.println("Suppression du tigre : " + myZoo.removeAnimal(tigre));
        System.out.println("Suppression du tigre (2e fois) : " + myZoo.removeAnimal(tigre));
        myZoo.displayAnimals();

        Zoo zoo2 = new Zoo("Petit Zoo", "Sfax");
        zoo2.addAnimal(new Animal("Canidé", "Loup", 6, true));
        System.out.println("Zoo 2 plein ? " + zoo2.isZooFull());
        Zoo plusGrand = Zoo.comparerZoo(myZoo, zoo2);
        System.out.println("Zoo avec le plus d'animaux : " + plusGrand.getName());

        // ===== Prosit 4 : tests d'encapsulation =====
        Animal ours = new Animal("Ursidé", "Ours", 7, true);
        ours.setAge(-3);                          // refusé
        System.out.println("Âge de l'ours : " + ours.getAge());
        ours.setAge(8);                           // accepté
        System.out.println("Âge de l'ours : " + ours.getAge());

        Zoo zooTest = new Zoo("", "Sousse");      // nom vide refusé
        System.out.println("Nom du zoo test : " + zooTest.getName());
        zooTest.setName("Zoo de Sousse");         // accepté
        System.out.println("Nom du zoo test : " + zooTest.getName());

        zooTest.setNbrCages(3);
        System.out.println("Nombre de cages du zoo test : " + zooTest.getNbrCages());
        zooTest.setNbrCages(-1);                  // refusé
        System.out.println("Nombre de cages après tentative invalide : " + zooTest.getNbrCages());

        // ===== Prosit 5 : Héritage =====
        Aquatic aquatic = new Aquatic();
        Terrestrial terrestrial = new Terrestrial();
        Dolphin dolphin = new Dolphin();
        Penguin penguin = new Penguin();

        System.out.println("\n=== Héritage - instanciations par défaut ===");
        System.out.println(aquatic);
        System.out.println(terrestrial);
        System.out.println(dolphin);
        System.out.println(penguin);

        Aquatic aquatic2 = new Aquatic("Poisson", "Requin", 4, true, "océan");
        Terrestrial terrestrial2 = new Terrestrial("Mammifère", "Zèbre", 5, true, 4);
        Dolphin dolphin2 = new Dolphin("Mammifère", "Dauphin", 7, true, "mer", 34.5f);
        Penguin penguin2 = new Penguin("Oiseau", "Pingouin", 3, false, "Antarctique", 120.0f);

        System.out.println("\n=== Héritage - constructeurs paramétrés ===");
        System.out.println(aquatic2);
        System.out.println(terrestrial2);
        System.out.println(dolphin2);
        System.out.println(penguin2);

        System.out.println("\n=== Comportement de nage ===");
        aquatic2.swim();
        dolphin2.swim();
        penguin2.swim();

        sc.close();
    }
}