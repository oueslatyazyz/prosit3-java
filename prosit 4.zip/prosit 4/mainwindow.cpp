#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include <QMessageBox>
#include <QPoint>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , dotsMenu(nullptr)
    , filtreMenu(nullptr)
{
    ui->setupUi(this);

    // ===== MENU "3 POINTS" =====
    dotsMenu = new QMenu(this);

    // 👇 nouvelle action ajoutée en premier
    actionAfficher = dotsMenu->addAction("Afficher les données d’un client");
    actionModifier = dotsMenu->addAction("Modifier un client");
    actionAjouter  = dotsMenu->addAction("Ajouter un client");
    actionSupprimer = dotsMenu->addAction("Supprimer un client");

    connect(actionAfficher, &QAction::triggered, this, &MainWindow::onActionAfficherClient);
    connect(actionModifier, &QAction::triggered, this, &MainWindow::onActionModifierClient);
    connect(actionAjouter,  &QAction::triggered, this, &MainWindow::onActionAjouterClient);
    connect(actionSupprimer,&QAction::triggered, this, &MainWindow::onActionSupprimerClient);

    dotsMenu->setStyleSheet(
        "QMenu { background-color: #ffffff; border: 1px solid #cccccc; border-radius: 8px; padding: 4px; }"
        "QMenu::item { padding: 8px 20px; }"
        "QMenu::item:selected { background-color: #0078d7; color: white; }"
        );

    // ===== MENU "FILTRES" =====
    filtreMenu = new QMenu(this);
    filtreNom  = filtreMenu->addAction("Nom");
    filtrePays = filtreMenu->addAction("Pays");
    filtreDate = filtreMenu->addAction("Date d'ajout");

    connect(filtreNom,  &QAction::triggered, this, &MainWindow::onFiltreNom);
    connect(filtrePays, &QAction::triggered, this, &MainWindow::onFiltrePays);
    connect(filtreDate, &QAction::triggered, this, &MainWindow::onFiltreDateAjout);

    filtreMenu->setStyleSheet(
        "QMenu { background-color: #ffffff; border: 1px solid #cccccc; border-radius: 8px; padding: 4px; }"
        "QMenu::item { padding: 8px 20px; }"
        "QMenu::item:selected { background-color: #0078d7; color: white; }"
        );

    // Connexions des boutons
    wireUi();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::wireUi()
{
    stacked          = this->findChild<QStackedWidget*>("stackedWidget");
    leIdClient       = this->findChild<QLineEdit*>("lineEdit_idClient");
    leIdSupp         = this->findChild<QLineEdit*>("lineEdit_idSupp");
    leNomAjout       = this->findChild<QLineEdit*>("lineEdit_nomAjout");
    btnRecherche     = this->findChild<QPushButton*>("pushButton_recherche");
    btnRetour        = this->findChild<QPushButton*>("pushButton_retour");
    btnDots          = this->findChild<QPushButton*>("pushButton_dots");
    btnFiltre        = this->findChild<QPushButton*>("pushButton_filtre");
    btnValiderAjout  = this->findChild<QPushButton*>("pushButton_validerAjout");
    btnValiderSupp   = this->findChild<QPushButton*>("pushButton_validerSupp");
    btnRetourFiche   = this->findChild<QPushButton*>("pushButton_retourFiche");
    btnRetourAjout   = this->findChild<QPushButton*>("pushButton_retourAjout");
    btnRetourSupp    = this->findChild<QPushButton*>("pushButton_retourSupp");

    if (btnDots)
        connect(btnDots, &QPushButton::clicked, this, [this]() {
            QPoint pos = ui->pushButton_dots->mapToGlobal(QPoint(0, ui->pushButton_dots->height()));
            dotsMenu->exec(pos);
        });

    if (btnFiltre)
        connect(btnFiltre, &QPushButton::clicked, this, [this]() {
            QPoint pos = ui->pushButton_filtre->mapToGlobal(QPoint(0, ui->pushButton_filtre->height()));
            filtreMenu->exec(pos);
        });

    if (btnRecherche)
        connect(btnRecherche, &QPushButton::clicked, this, &MainWindow::onRechercheClicked);

    if (btnRetour)
        connect(btnRetour, &QPushButton::clicked, this, &MainWindow::onRetourClicked);

    if (btnValiderAjout)
        connect(btnValiderAjout, &QPushButton::clicked, this, &MainWindow::onValiderAjoutClicked);

    if (btnValiderSupp)
        connect(btnValiderSupp, &QPushButton::clicked, this, &MainWindow::onValiderSuppressionClicked);

    if (btnRetourFiche)
        connect(btnRetourFiche, &QPushButton::clicked, this, &MainWindow::onRetourClicked);
    if (btnRetourAjout)
        connect(btnRetourAjout, &QPushButton::clicked, this, &MainWindow::onRetourClicked);
    if (btnRetourSupp)
        connect(btnRetourSupp, &QPushButton::clicked, this, &MainWindow::onRetourClicked);
}

// ======== MENUS ========
void MainWindow::onActionAfficherClient() {
    if (stacked) stacked->setCurrentIndex(idxModifierClient); // page 2 = saisir ID
}

void MainWindow::onActionModifierClient() {
    if (stacked) stacked->setCurrentIndex(idxModifierClient); // page 2
}

void MainWindow::onActionAjouterClient() {
    if (stacked) stacked->setCurrentIndex(idxAjouterClient); // page 4
}

void MainWindow::onActionSupprimerClient() {
    if (stacked) stacked->setCurrentIndex(idxSupprimerClient); // page 5
}

// ======== FILTRES ========
void MainWindow::onFiltreNom()  { QMessageBox::information(this, "Filtre", "Tri par Nom (A → Z)"); }
void MainWindow::onFiltrePays() { QMessageBox::information(this, "Filtre", "Tri par Pays"); }
void MainWindow::onFiltreDateAjout() { QMessageBox::information(this, "Filtre", "Tri par Date d'ajout"); }

// ======== AUTRES ========
void MainWindow::onRechercheClicked()
{
    if (!stacked) return;
    QString id = leIdClient ? leIdClient->text() : "";
    if (id.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez entrer un ID client !");
        return;
    }

    // après saisie ID, aller page 3
    stacked->setCurrentIndex(idxFicheClient);
}

void MainWindow::onRetourClicked()
{
    if (stacked) stacked->setCurrentIndex(idxDashboard);
}

void MainWindow::onValiderAjoutClicked()
{
    QString nom = leNomAjout ? leNomAjout->text() : "";
    if (nom.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez entrer le nom du client !");
        return;
    }
    QMessageBox::information(this, "Succès", "Client ajouté avec succès !");
    stacked->setCurrentIndex(idxDashboard);
}

void MainWindow::onValiderSuppressionClicked()
{
    QString id = leIdSupp ? leIdSupp->text() : "";
    if (id.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez entrer l'ID du client !");
        return;
    }
    QMessageBox::information(this, "Suppression", "Client supprimé avec succès !");
    stacked->setCurrentIndex(idxDashboard);
}
