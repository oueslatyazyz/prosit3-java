#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMenu>
#include <QAction>
#include <QStackedWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // === Menu "3 points" ===
    void onActionAfficherClient();
    void onActionModifierClient();
    void onActionAjouterClient();
    void onActionSupprimerClient();

    // === Filtres ===
    void onFiltreNom();
    void onFiltrePays();
    void onFiltreDateAjout();

    // === Autres boutons ===
    void onRechercheClicked();
    void onRetourClicked();
    void onValiderAjoutClicked();
    void onValiderSuppressionClicked();

private:
    Ui::MainWindow *ui;

    // --- Menu des trois points ---
    QMenu   *dotsMenu;
    QAction *actionAfficher;   // 👈 nouvelle action
    QAction *actionModifier;
    QAction *actionAjouter;
    QAction *actionSupprimer;

    // --- Menu des filtres ---
    QMenu   *filtreMenu;
    QAction *filtreNom;
    QAction *filtrePays;
    QAction *filtreDate;

    // --- Widgets principaux ---
    QStackedWidget *stacked = nullptr;

    // Champs et boutons
    QLineEdit   *leIdClient = nullptr;
    QLineEdit   *leIdSupp   = nullptr;
    QLineEdit   *leNomAjout = nullptr;
    QPushButton *btnRecherche = nullptr;
    QPushButton *btnRetour = nullptr;
    QPushButton *btnDots = nullptr;
    QPushButton *btnFiltre = nullptr;
    QPushButton *btnValiderAjout = nullptr;
    QPushButton *btnValiderSupp = nullptr;
    QPushButton *btnRetourFiche = nullptr;
    QPushButton *btnRetourAjout = nullptr;
    QPushButton *btnRetourSupp = nullptr;

    // Index des pages
    int idxDashboard        = 0;
    int idxModifierClient   = 1;
    int idxFicheClient      = 2;
    int idxAjouterClient    = 3;
    int idxSupprimerClient  = 4;

    // Fonction pour relier les widgets
    void wireUi();
};

#endif // MAINWINDOW_H
