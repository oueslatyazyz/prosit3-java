import entities.Employe;
import service.SocieteArrayList;

public class Main {
    public static void main(String[] args) {
        SocieteArrayList societe = new SocieteArrayList();

        Employe employe1 = new Employe(3, "Ben Ali", "Sami", "Informatique", 2);
        Employe employe2 = new Employe(1, "Trabelsi", "Amel", "Ressources humaines", 1);
        Employe employe3 = new Employe(2, "Mansour", "Nadia", "Informatique", 1);
        Employe employe4 = new Employe(4, "Jaziri", "Karim", "Informatique", 1);

        societe.ajouterEmploye(employe1);
        societe.ajouterEmploye(employe2);
        societe.ajouterEmploye(employe3);
        societe.ajouterEmploye(employe4);

        System.out.println("Tous les employes :");
        societe.displayEmploye();

        System.out.println("\nRecherche par nom (Mansour) : "
                + societe.rechercherEmploye("Mansour"));
        System.out.println("Recherche de l'employe " + employe2 + " : "
                + societe.rechercherEmploye(employe2));

        societe.trierEmployeParId();
        System.out.println("\nTri par identifiant :");
        societe.displayEmploye();

        societe.trierEmployeParNomDepartementEtGrade();
        System.out.println("\nTri par departement, grade et nom :");
        societe.displayEmploye();

        System.out.println("\nEmployes du departement Informatique :");
        for (Employe employe : societe.rechercherParDepartement("Informatique")) {
            System.out.println(employe);
        }

        societe.supprimerEmploye(employe2);
        System.out.println("\nApres suppression de " + employe2.getNom() + " :");
        societe.displayEmploye();
    }
}
