package entities;

import java.util.Objects;

public class Employe implements Comparable<Employe> {
    private int id;
    private String nom;
    private String prenom;
    private String nomDepartement;
    private int grade;

    public Employe() {
    }

    public Employe(int id, String nom, String prenom, String nomDepartement, int grade) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.nomDepartement = nomDepartement;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNomDepartement() {
        return nomDepartement;
    }

    public void setNomDepartement(String nomDepartement) {
        this.nomDepartement = nomDepartement;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    @Override
    public int compareTo(Employe autre) {
        return Integer.compare(id, autre.id);
    }

    @Override
    public boolean equals(Object objet) {
        if (this == objet) {
            return true;
        }
        if (!(objet instanceof Employe)) {
            return false;
        }
        Employe autre = (Employe) objet;
        return id == autre.id
                && grade == autre.grade
                && Objects.equals(nom, autre.nom)
                && Objects.equals(prenom, autre.prenom)
                && Objects.equals(nomDepartement, autre.nomDepartement);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nom, prenom, nomDepartement, grade);
    }

    @Override
    public String toString() {
        return "Employe{"
                + "id=" + id
                + ", nom='" + nom + '\''
                + ", prenom='" + prenom + '\''
                + ", nomDepartement='" + nomDepartement + '\''
                + ", grade=" + grade
                + '}';
    }
}
