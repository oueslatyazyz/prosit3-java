package service;

import interfaces.IGestion;
import interfaces.IRechercheAvancee;
import entities.Employe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SocieteArrayList implements IGestion<Employe>, IRechercheAvancee<Employe> {
    private final ArrayList<Employe> employes = new ArrayList<>();

    @Override
    public void ajouterEmploye(Employe employe) {
        employes.add(employe);
    }

    @Override
    public boolean rechercherEmploye(String nom) {
        if (nom == null) {
            return false;
        }
        for (Employe employe : employes) {
            if (employe.getNom() != null && employe.getNom().equalsIgnoreCase(nom)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean rechercherEmploye(Employe employe) {
        return employes.contains(employe);
    }

    @Override
    public void supprimerEmploye(Employe employe) {
        employes.remove(employe);
    }

    @Override
    public void displayEmploye() {
        for (Employe employe : employes) {
            System.out.println(employe);
        }
    }

    @Override
    public void trierEmployeParId() {
        Collections.sort(employes);
    }

    @Override
    public void trierEmployeParNomDepartementEtGrade() {
        Comparator<Employe> comparateur = Comparator
                .comparing(Employe::getNomDepartement,
                        Comparator.nullsFirst(String.CASE_INSENSITIVE_ORDER))
                .thenComparingInt(Employe::getGrade)
                .thenComparing(Employe::getNom,
                        Comparator.nullsFirst(String.CASE_INSENSITIVE_ORDER));
        Collections.sort(employes, comparateur);
    }

    @Override
    public List<Employe> rechercherParDepartement(String nomDepartement) {
        List<Employe> resultat = new ArrayList<>();
        if (nomDepartement == null) {
            return resultat;
        }
        for (Employe employe : employes) {
            String departement = employe.getNomDepartement();
            if (departement != null && departement.equalsIgnoreCase(nomDepartement)) {
                resultat.add(employe);
            }
        }
        return resultat;
    }
}
