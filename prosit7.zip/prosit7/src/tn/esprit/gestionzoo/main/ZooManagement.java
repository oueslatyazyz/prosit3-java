package tn.esprit.gestionzoo.main;

import tn.esprit.gestionzoo.entities.Animal;
import tn.esprit.gestionzoo.entities.Aquatic;
import tn.esprit.gestionzoo.entities.Dolphin;
import tn.esprit.gestionzoo.entities.InvalidAgeException;
import tn.esprit.gestionzoo.entities.Penguin;
import tn.esprit.gestionzoo.entities.Terrestrial;
import tn.esprit.gestionzoo.entities.Zoo;
import tn.esprit.gestionzoo.entities.ZooFullException;

import java.util.Scanner;

public class ZooManagement {
    public static void main(String[] args) {
        // ===== Saisie avec validation =====,k
        Scanner sc = new Scanner(System.in);

        String zooName = "Mon Zoo";
        if (sc.hasNextLine()) {
            do {
                System.out.print("Entrez le nom du zoo : ");
                zooName = sc.nextLine().trim();
            } while (zooName.isEmpty());
        } else {
            System.out.println("Aucune saisie détectée, utilisation du nom par défaut : " + zooName);
        }

        int nbrCages = 25;
        if (sc.hasNextInt()) {
            do {
                System.out.print("Entrez le nombre de cages (entier positif) : ");
                while (!sc.hasNextInt()) {
                    System.out.print("Entier requis : ");
                    sc.next();
                }
                nbrCages = sc.nextInt();
            } while (nbrCages <= 0);
        } else {
            System.out.println("Aucune valeur saisie, utilisation de 25 cages par défaut.");
        }

        System.out.println(zooName + " comporte " + nbrCages + " cages.");

        // ===== Prosit 3 =====
        Zoo myZoo = new Zoo(zooName, "Tunis", nbrCages);
        myZoo.displayZoo();

        Animal lion = new Animal("Félidé", "Lion", 5, true);
        Animal tigre = new Animal("Félidé", "Tigre", 4, true);
        Animal aigle = new Animal("Accipitridé", "Aigle", 3, false);

        try {
            myZoo.addAnimal(lion);
            System.out.println("Ajout lion  : réussi");
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur lors de l'ajout du lion : " + e.getMessage());
        }

        try {
            myZoo.addAnimal(tigre);
            System.out.println("Ajout tigre : réussi");
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur lors de l'ajout du tigre : " + e.getMessage());
        }

        try {
            myZoo.addAnimal(aigle);
            System.out.println("Ajout aigle : réussi");
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur lors de l'ajout de l'aigle : " + e.getMessage());
        }

        myZoo.displayAnimals();
        System.out.println("Recherche lion : " + myZoo.searchAnimal(lion));

        Animal lionCopie = new Animal("Félidé", "Lion", 5, true);
        System.out.println("Recherche copie du lion : " + myZoo.searchAnimal(lionCopie));
        try {
            myZoo.addAnimal(lionCopie);
            System.out.println("Ajout de la copie du lion : réussi");
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur lors de l'ajout de la copie du lion : " + e.getMessage());
        }

        for (int i = 1; i <= 25; i++) {
            try {
                myZoo.addAnimal(new Animal("Test", "Animal" + i, 1, true));
                System.out.println("Ajout Animal" + i + " : réussi");
            } catch (ZooFullException | InvalidAgeException e) {
                System.out.println("Ajout refusé pour Animal" + i + " : " + e.getMessage());
                break;
            }
        }
        System.out.println(myZoo);

        System.out.println("Suppression du tigre : " + myZoo.removeAnimal(tigre));
        System.out.println("Suppression du tigre (2e fois) : " + myZoo.removeAnimal(tigre));
        myZoo.displayAnimals();

        Zoo zoo2 = new Zoo("Petit Zoo", "Sfax");
        try {
            zoo2.addAnimal(new Animal("Canidé", "Loup", 6, true));
            System.out.println("Zoo 2 plein ? " + zoo2.isZooFull());
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur sur le zoo 2 : " + e.getMessage());
        }
        Zoo plusGrand = Zoo.comparerZoo(myZoo, zoo2);
        System.out.println("Zoo avec le plus d'animaux : " + plusGrand.getName());

        // ===== Prosit 4 : tests d'encapsulation =====
        Animal ours = new Animal("Ursidé", "Ours", 7, true);
        ours.setAge(-3);                          // refusé
        System.out.println("Âge de l'ours : " + ours.getAge());
        ours.setAge(8);                           // accepté
        System.out.println("Âge de l'ours : " + ours.getAge());

        Zoo zooTest = new Zoo("", "Sousse");      // nom vide refusé
        System.out.println("Nom du zoo test : " + zooTest.getName());
        zooTest.setName("Zoo de Sousse");         // accepté
        System.out.println("Nom du zoo test : " + zooTest.getName());

        zooTest.setNbrCages(3);
        System.out.println("Nombre de cages du zoo test : " + zooTest.getNbrCages());
        zooTest.setNbrCages(-1);                  // refusé
        System.out.println("Nombre de cages après tentative invalide : " + zooTest.getNbrCages());

        // ===== Prosit 5 : Héritage =====
        Terrestrial terrestrial = new Terrestrial();
        Dolphin dolphin = new Dolphin();
        Penguin penguin = new Penguin();

        System.out.println("\n=== Héritage - instanciations par défaut ===");
        System.out.println(terrestrial);
        System.out.println(dolphin);
        System.out.println(penguin);

        Aquatic aquaticRef = new Dolphin("Mammifère", "Dauphin", 7, true, "mer", 34.5f);
        Terrestrial terrestrial2 = new Terrestrial("Mammifère", "Zèbre", 5, true, 4);
        Dolphin dolphin2 = new Dolphin("Mammifère", "Dauphin", 7, true, "mer", 34.5f);
        Penguin penguin2 = new Penguin("Oiseau", "Pingouin", 3, false, "Antarctique", 120.0f);

        System.out.println("\n=== Héritage - constructeurs paramétrés ===");
        System.out.println(aquaticRef);
        System.out.println(terrestrial2);
        System.out.println(dolphin2);
        System.out.println(penguin2);

        System.out.println("\n=== Comportement de nage ===");
        aquaticRef.swim();
        dolphin2.swim();
        penguin2.swim();

        // ===== Prosit 6 : Tableau d'animaux aquatiques =====
        Zoo zooAquatique = new Zoo("Zoo Aquatique", "Sousse", 10);
        zooAquatique.addAquaticAnimal(new Dolphin("Mammifère", "Flipper", 9, true, "mer", 28.0f));
        zooAquatique.addAquaticAnimal(new Penguin("Oiseau", "Pingu", 4, false, "Antarctique", 90.0f));
        zooAquatique.addAquaticAnimal(new Dolphin("Mammifère", "Dora", 6, true, "océan", 30.0f));
        zooAquatique.addAquaticAnimal(new Penguin("Oiseau", "Tux", 5, false, "mer", 115.0f));

        System.out.println("\n=== Prosit 6 - Tableau aquatique ===");
        zooAquatique.swimAllAquaticAnimals();
        System.out.println("Profondeur maximale des pingouins : " + zooAquatique.getMaxPenguinDepth());
        zooAquatique.displayDolphinAndPenguinCount();

        Dolphin dolphin3 = new Dolphin("Mammifère", "Dora", 6, true, "océan", 30.0f);
        System.out.println("Égalité des animaux aquatiques : " + zooAquatique.searchAquaticAnimal(dolphin3));
        System.out.println("Dolphin equals Dolphin : " + dolphin3.equals(new Dolphin("Mammifère", "Dora", 6, true, "océan", 30.0f)));

        // ===== Prosit 7 : Exceptions personnalisées =====
        Zoo zooException = new Zoo("Zoo Exceptions", "Tunis", 3);
        Animal validAnimal = new Animal("Félidé", "Lynx", 2, true);
        Animal negativeAgeAnimal = new Animal("Félidé", "Panthère", -1, true);

        try {
            zooException.addAnimal(validAnimal);
            System.out.println("Ajout animal valide : réussi");
            System.out.println("Nombre d'animaux : " + zooException.getAnimalCount());
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur : " + e.getMessage());
        }

        try {
            zooException.addAnimal(negativeAgeAnimal);
            System.out.println("Ajout animal âge négatif : réussi");
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur âge invalide : " + e.getMessage());
        }

        try {
            zooException.addAnimal(new Animal("Canidé", "Wolf", 4, true));
            zooException.addAnimal(new Animal("Oiseau", "Hibou", 2, false));
            zooException.addAnimal(new Animal("Reptile", "Serpent", 1, false));
            zooException.addAnimal(new Animal("Mammifère", "Bison", 6, true));
        } catch (ZooFullException | InvalidAgeException e) {
            System.out.println("Erreur de capacité : " + e.getMessage());
        }

        System.out.println("Nombre total d'animaux après essais : " + zooException.getAnimalCount());

        sc.close();
    }
}