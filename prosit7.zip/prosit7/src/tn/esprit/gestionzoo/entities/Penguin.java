package tn.esprit.gestionzoo.entities;

public class Penguin extends Aquatic {
    protected float swimmingDepth;

    public Penguin() {
        super();
        this.swimmingDepth = 0.0f;
    }

    public Penguin(String family, String name, int age, boolean isMammal, String habitat, float swimmingDepth) {
        super(family, name, age, isMammal, habitat);
        setSwimmingDepth(swimmingDepth);
    }

    public float getSwimmingDepth() {
        return swimmingDepth;
    }

    public void setSwimmingDepth(float swimmingDepth) {
        if (swimmingDepth < 0) {
            System.out.println("Erreur : la profondeur de nage ne peut pas être négative.");
            return;
        }
        this.swimmingDepth = swimmingDepth;
    }

    @Override
    public void swim() {
        System.out.println("This penguin is swimming.");
    }

    @Override
    public String toString() {
        return "Penguin [Famille=" + getFamily() + ", Nom=" + getName() + ", Âge=" + getAge()
                + ", Mammifère=" + isMammal() + ", Habitat=" + habitat + ", Profondeur de nage=" + swimmingDepth + "]";
    }
}
