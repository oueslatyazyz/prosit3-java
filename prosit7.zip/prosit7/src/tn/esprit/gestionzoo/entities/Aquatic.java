package tn.esprit.gestionzoo.entities;

import java.util.Objects;

public abstract class Aquatic extends Animal {
    protected String habitat;

    public Aquatic() {
        super();
        this.habitat = "Inconnu";
    }

    public Aquatic(String family, String name, int age, boolean isMammal, String habitat) {
        super(family, name, age, isMammal);
        setHabitat(habitat);
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        if (habitat == null || habitat.trim().isEmpty()) {
            System.out.println("Erreur : l'habitat ne peut pas être vide.");
            return;
        }
        this.habitat = habitat.trim();
    }

    public abstract void swim();

    @Override
    public String toString() {
        return "Aquatic [Famille=" + getFamily() + ", Nom=" + getName() + ", Âge=" + getAge()
                + ", Mammifère=" + isMammal() + ", Habitat=" + habitat + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Aquatic)) {
            return false;
        }
        Aquatic other = (Aquatic) obj;
        return Objects.equals(this.name, other.name)
                && this.age == other.age
                && Objects.equals(this.habitat, other.habitat);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age, habitat);
    }
}
