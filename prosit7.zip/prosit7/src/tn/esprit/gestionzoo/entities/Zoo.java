package tn.esprit.gestionzoo.entities;

public class Zoo {
    private static final int MAX_AQUATIC_ANIMALS = 10;

    private int nbrCages;                       // capacité modifiable via setter, avec validation
    private Animal[] animals;
    private int animalCount = 0;                // compteur d'animaux présents
    private String name = "Zoo sans nom";     // valeur par défaut valide
    private String city = "Inconnue";
    private Aquatic[] aquaticAnimals;
    private int aquaticAnimalCount = 0;

    public Zoo() {
        this("Zoo sans nom", "Inconnue", 25);
    }

    public Zoo(String name, String city) {
        this(name, city, 25);
    }

    public Zoo(String name, String city, int nbrCages) {
        this.animals = new Animal[0];
        this.aquaticAnimals = new Aquatic[MAX_AQUATIC_ANIMALS];
        setName(name);
        setCity(city);
        setNbrCages(nbrCages);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            System.out.println("Erreur : le nom du zoo ne peut pas être vide.");
            return;
        }
        this.name = name.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        if (city == null || city.trim().isEmpty()) {
            System.out.println("Erreur : la ville du zoo ne peut pas être vide.");
            return;
        }
        this.city = city.trim();
    }

    public int getNbrCages() {
        return nbrCages;
    }

    public void setNbrCages(int nbrCages) {
        if (nbrCages <= 0) {
            System.out.println("Erreur : le nombre de cages doit être strictement positif.");
            return;
        }
        if (animalCount > nbrCages) {
            System.out.println("Erreur : impossible de réduire le zoo à " + nbrCages + " cages, il contient déjà " + animalCount + " animaux.");
            return;
        }

        Animal[] newAnimals = new Animal[nbrCages];
        for (int i = 0; i < animalCount; i++) {
            newAnimals[i] = animals[i];
        }
        this.animals = newAnimals;
        this.nbrCages = nbrCages;
    }

    public int getAnimalCount() {
        return animalCount;
    }

    public void displayZoo() {
        System.out.println("Zoo : " + name + ", Ville : " + city + ", Cages : " + nbrCages);
    }

    @Override
    public String toString() {
        return "Zoo [Nom=" + name + ", Ville=" + city + ", Cages=" + nbrCages
                + ", Animaux=" + animalCount + "]";
    }

    public boolean isZooFull() {
        return animalCount >= nbrCages;
    }

    public void addAnimal(Animal animal) throws ZooFullException, InvalidAgeException {
        if (animal == null) {
            return;
        }
        if (animal.getAge() < 0) {
            throw new InvalidAgeException("Âge d’animal invalide : l’âge ne peut pas être négatif.");
        }
        if (isZooFull()) {
            throw new ZooFullException("Le zoo est plein, impossible d’ajouter un nouvel animal.");
        }
        if (searchAnimal(animal) != -1) {
            System.out.println("Animal déjà présent dans le zoo : " + animal.getName());
            return;
        }
        animals[animalCount] = animal;
        animalCount++;
    }

    public void displayAnimals() {
        if (animalCount == 0) {
            System.out.println("Aucun animal dans le zoo " + name);
            return;
        }
        System.out.println("Animaux du zoo " + name + " (" + animalCount + "/" + nbrCages + ") :");
        for (int i = 0; i < animalCount; i++) {
            System.out.println("  [" + i + "] " + animals[i]);
        }
    }

    public int searchAnimal(Animal animal) {
        if (animal == null || animal.getName() == null) {
            return -1;
        }
        for (int i = 0; i < animalCount; i++) {
            if (animals[i] != null && animals[i].getName().equalsIgnoreCase(animal.getName())) {
                return i;
            }
        }
        return -1;
    }

    public boolean removeAnimal(Animal animal) {
        int index = searchAnimal(animal);
        if (index == -1) {
            return false;
        }
        for (int i = index; i < animalCount - 1; i++) {
            animals[i] = animals[i + 1];
        }
        animals[animalCount - 1] = null;
        animalCount--;
        return true;
    }

    public boolean addAquaticAnimal(Aquatic aquaticAnimal) {
        if (aquaticAnimal == null) {
            return false;
        }
        if (aquaticAnimalCount >= aquaticAnimals.length) {
            System.out.println("Erreur : le tableau des animaux aquatiques est plein.");
            return false;
        }
        if (searchAquaticAnimal(aquaticAnimal) != -1) {
            return false;
        }
        aquaticAnimals[aquaticAnimalCount] = aquaticAnimal;
        aquaticAnimalCount++;
        return true;
    }

    public int searchAquaticAnimal(Aquatic aquaticAnimal) {
        if (aquaticAnimal == null) {
            return -1;
        }
        for (int i = 0; i < aquaticAnimalCount; i++) {
            if (aquaticAnimals[i] != null && aquaticAnimals[i].equals(aquaticAnimal)) {
                return i;
            }
        }
        return -1;
    }

    public void swimAllAquaticAnimals() {
        if (aquaticAnimalCount == 0) {
            System.out.println("Aucun animal aquatique dans le zoo " + name);
            return;
        }
        for (int i = 0; i < aquaticAnimalCount; i++) {
            aquaticAnimals[i].swim();
        }
    }

    public float getMaxPenguinDepth() {
        float maxDepth = 0.0f;
        for (int i = 0; i < aquaticAnimalCount; i++) {
            if (aquaticAnimals[i] instanceof Penguin) {
                Penguin penguin = (Penguin) aquaticAnimals[i];
                if (penguin.getSwimmingDepth() > maxDepth) {
                    maxDepth = penguin.getSwimmingDepth();
                }
            }
        }
        return maxDepth;
    }

    public void displayDolphinAndPenguinCount() {
        int dolphinCount = 0;
        int penguinCount = 0;

        for (int i = 0; i < aquaticAnimalCount; i++) {
            if (aquaticAnimals[i] instanceof Dolphin) {
                dolphinCount++;
            } else if (aquaticAnimals[i] instanceof Penguin) {
                penguinCount++;
            }
        }

        System.out.println("Nombre de dauphins : " + dolphinCount);
        System.out.println("Nombre de pingouins : " + penguinCount);
    }

    public static Zoo comparerZoo(Zoo z1, Zoo z2) {
        if (z1 == null && z2 == null) {
            return null;
        }
        if (z1 == null) {
            return z2;
        }
        if (z2 == null) {
            return z1;
        }
        return (z1.getAnimalCount() >= z2.getAnimalCount()) ? z1 : z2;
    }
}